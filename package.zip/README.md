# MODELOS DAS INTERFACE PARA SER USADA NO PROJETO.

https://www.figma.com/file/bjFYpO0VU0Y8l2bWALFCvt/Burger-shop

